-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 18, 2021 at 07:51 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `martial`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `balance` int(11) NOT NULL,
  `month` varchar(8) NOT NULL,
  `year` varchar(4) NOT NULL,
  `t_email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `belt_test`
--

CREATE TABLE `belt_test` (
  `belt_quantity` int(30) NOT NULL,
  `location` varchar(60) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `competition`
--

CREATE TABLE `competition` (
  `name` varchar(30) NOT NULL,
  `sponsor` varchar(50) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `ID` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `manages`
--

CREATE TABLE `manages` (
  `T_email` varchar(30) NOT NULL,
  `test_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `T_mail` varchar(50) NOT NULL,
  `text` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `notifies`
--

CREATE TABLE `notifies` (
  `text` varchar(350) NOT NULL,
  `t_email` varchar(50) NOT NULL,
  `s_contact` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `organized_by`
--

CREATE TABLE `organized_by` (
  `T_email` varchar(30) NOT NULL,
  `comp_id` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `owns`
--

CREATE TABLE `owns` (
  `t_email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `participates`
--

CREATE TABLE `participates` (
  `student_contact` varchar(11) NOT NULL,
  `start_date` date NOT NULL,
  `points_earned` int(50) NOT NULL,
  `comp_id` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `pays`
--

CREATE TABLE `pays` (
  `student_contact` varchar(11) NOT NULL,
  `T_email` varchar(30) NOT NULL,
  `amount` int(255) NOT NULL,
  `due_date` date NOT NULL,
  `payment_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `joining_date` date NOT NULL,
  `address` varchar(60) NOT NULL,
  `email` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `contact` varchar(11) NOT NULL,
  `belt` varchar(50) NOT NULL,
  `balance` int(50) NOT NULL,
  `when_promoted` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `takes`
--

CREATE TABLE `takes` (
  `student_contact` varchar(11) NOT NULL,
  `test_date` date NOT NULL,
  `promotion` varchar(30) NOT NULL,
  `class_point` int(30) NOT NULL,
  `competition_point` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `trainer`
--

CREATE TABLE `trainer` (
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `salary` int(8) NOT NULL,
  `password` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `trains`
--

CREATE TABLE `trains` (
  `T_email` varchar(30) NOT NULL,
  `points_earned` int(50) NOT NULL,
  `day` varchar(20) NOT NULL,
  `time` time NOT NULL,
  `student_contact` varchar(11) NOT NULL,
  `student_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `belt_test`
--
ALTER TABLE `belt_test`
  ADD PRIMARY KEY (`date`);

--
-- Indexes for table `competition`
--
ALTER TABLE `competition`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `manages`
--
ALTER TABLE `manages`
  ADD KEY `T_email` (`T_email`),
  ADD KEY `test_date` (`test_date`);

--
-- Indexes for table `organized_by`
--
ALTER TABLE `organized_by`
  ADD UNIQUE KEY `comp_id` (`comp_id`),
  ADD UNIQUE KEY `T_email` (`T_email`);

--
-- Indexes for table `participates`
--
ALTER TABLE `participates`
  ADD KEY `comp_id` (`comp_id`),
  ADD KEY `student_contact` (`student_contact`);

--
-- Indexes for table `pays`
--
ALTER TABLE `pays`
  ADD PRIMARY KEY (`student_contact`,`T_email`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`contact`);

--
-- Indexes for table `takes`
--
ALTER TABLE `takes`
  ADD KEY `student_contact` (`student_contact`),
  ADD KEY `test_date` (`test_date`) USING BTREE;

--
-- Indexes for table `trainer`
--
ALTER TABLE `trainer`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `trains`
--
ALTER TABLE `trains`
  ADD KEY `T_email` (`T_email`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `participates`
--
ALTER TABLE `participates`
  ADD CONSTRAINT `participates_ibfk_1` FOREIGN KEY (`comp_id`) REFERENCES `competition` (`ID`),
  ADD CONSTRAINT `participates_ibfk_2` FOREIGN KEY (`student_contact`) REFERENCES `students` (`contact`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `takes`
--
ALTER TABLE `takes`
  ADD CONSTRAINT `takes_ibfk_1` FOREIGN KEY (`student_contact`) REFERENCES `students` (`contact`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `takes_ibfk_2` FOREIGN KEY (`test_date`) REFERENCES `belt_test` (`date`);

--
-- Constraints for table `trains`
--
ALTER TABLE `trains`
  ADD CONSTRAINT `trains_ibfk_1` FOREIGN KEY (`T_email`) REFERENCES `trainer` (`email`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
