package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.paint.Paint;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.Objects;
import java.util.ResourceBundle;

public class Take_Belt_Test implements Initializable {
    boolean refresh = true;
    int ptsNeeded = 0, ptsFromClass = 0, ptsFromCompetition = 0;
    double howMuchProgress = 0;
    String pno, date, beltTestDate, currentBelt, nextBelt;
    final int[] points_required = {0, 2000, 300, 40, 500, 600, 700, 800, 900};
    final String[] belt_color = {"white", "yellow", "green", "orange", "red", "blue", "purple", "brown", "black"};
    Connection con;

    @FXML
    private javafx.scene.control.TextField mobileNumber;
    @FXML
    private Text txtLabel;
    @FXML
    private javafx.scene.control.ProgressBar studentProgress;
    @FXML
    private javafx.scene.control.Label percentageLabel, showPromotedOrNotLabel;

    {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://127.0.0.1/martial", "root", "");
        } catch (Exception e) {
            System.out.println();
        }
    }

    public Take_Belt_Test() {
    }

    public void checkPromotion() throws SQLException {
        if (!refresh) {
            showPromotedOrNotLabel.setText("Please refresh first!");
            return;
        }
        pno = mobileNumber.getText();
        boolean found = false;
        if (pno.length() != 11 || notNumber(mobileNumber)) {
            showPromotedOrNotLabel.setText("Sorry you did not enter a mobile number!");
            mobileNumber.setText("");
        } else {
            Statement st = con.createStatement();
            ResultSet fs = st.executeQuery(String.format("select contact from students where contact = '%s';", pno));
            while (fs.next()) {
                if (fs.getString(1).equals(pno)) {
                    found = true;
                }
            }
            if (!found) {
                showPromotedOrNotLabel.setText("Sorry you are not a valid student!");
                mobileNumber.setText("");
            }
        }
        if (found) {
            calculate();
        }
        refresh = false;
    }

    public void welcome(ActionEvent event) throws IOException {
        set("Welcome.fxml", event);
    }


    public void set(String sendTo, ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource(sendTo)));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    private boolean notNumber(TextField s) {
        String str = String.valueOf(s);
        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);
            if (c < '0' || c > '9') {
                return false;
            }
        }
        return true;
    }

    public void calculate() throws SQLException {

        int quantity = 0, count = 0;
        Date today = Date.valueOf(java.time.LocalDate.now());
        Statement bt = con.createStatement(), st = con.createStatement(), t = con.createStatement();
        ResultSet fs = st.executeQuery(String.format("select belt, when_promoted from students where contact = '%s';", pno));
        ResultSet fbt = bt.executeQuery("select belt_quantity, date from belt_test order by date limit 1");
        ResultSet ft = t.executeQuery(String.format("select test_date from takes where student_contact ='%s';", pno));

        while (fbt.next()) {
            quantity = fbt.getInt(1);
            beltTestDate = fbt.getString(2);
            if (quantity == 0) {
                showPromotedOrNotLabel.setText("Sorry remaining belt quantity 0, try next time!");
                return;
            } else if (today.compareTo(Date.valueOf(beltTestDate)) != 0) {
                showPromotedOrNotLabel.setText("Sorry the test date is not today or has passed!");
                return;
            }
        }

        while (ft.next()) {
            if (today.compareTo(ft.getDate(1)) == 0) {
                showPromotedOrNotLabel.setText("You have already taken the test!");
                return;
            }
        }


        while (fs.next()) {
            currentBelt = fs.getString(1);
            date = fs.getString(2);
        }

        if (currentBelt.equals("Black")) {
            showPromotedOrNotLabel.setText("You are the Master, nothing is left for you!!!");
            return;
        }

        for (int i = 0; i < 9; i++) {
            if (belt_color[i].equals(currentBelt)) {
                ptsNeeded = points_required[i + 1];
                nextBelt = belt_color[i + 1];
            }
        }

        ResultSet pointsFromCompetition = st.executeQuery(String.format("select count(points_earned), sum" +
                "(points_earned) from " +
                "participates where student_contact = '%s' and start_date >= '%s';", pno, date));

        while (pointsFromCompetition.next()) {
            count = pointsFromCompetition.getInt(1);
            ptsFromCompetition = pointsFromCompetition.getInt(2);
        }

        ResultSet pointsFromClass = st.executeQuery(String.format("select points_earned from trains where student_contact = '%s';", pno));
        while (pointsFromClass.next()) {
            ptsFromClass += pointsFromClass.getInt(1);
        }

        progress();
        String promotion = "promoted";
        if ((ptsFromClass + ptsFromCompetition) < ptsNeeded) {
            showPromotedOrNotLabel.setText("Sorry you don't have enough points for promotion!");
            promotion = "Did not promote";
        } else if (count < 3) {
            showPromotedOrNotLabel.setText("You have to participate in at least 3 competitions!");
        } else {
            showPromotedOrNotLabel.setText("Congratulations!!! You have been promoted to belt");
            txtLabel.setText("'" + nextBelt + "'");
            txtLabel.setFill(Paint.valueOf(nextBelt));
            PreparedStatement pst = con.prepareStatement("update students set belt = ?, when_promoted = ? where " +
                    "contact = ?");
            pst.setString(1, nextBelt);
            pst.setDate(2, Date.valueOf(java.time.LocalDate.now()));
            pst.setString(3, pno);
            pst.executeUpdate();

            PreparedStatement s = con.prepareStatement("update trains set points_earned = ? where student_contact = " +
                    "?");
            s.setInt(1, (0));
            s.setString(2, pno);
            s.executeUpdate();
        }

        PreparedStatement pst2 = con.prepareStatement("insert into takes values (?, ?, ?, ?, ?)");
        pst2.setString(1, pno);
        pst2.setDate(2, Date.valueOf(java.time.LocalDate.now()));
        pst2.setString(3, promotion);
        pst2.setInt(4, ptsFromClass);
        pst2.setInt(5, ptsFromCompetition);
        pst2.executeUpdate();

        PreparedStatement pst3 = con.prepareStatement("update belt_test set belt_quantity = ?");
        pst3.setInt(1, quantity - 1);
        pst3.executeUpdate();
    }

    private void progress() {
        howMuchProgress += ((ptsFromClass + ptsFromCompetition) * 100.0 / (ptsNeeded)) / 100.0;
        studentProgress.setProgress(howMuchProgress);
        if (howMuchProgress < 1) {
            percentageLabel.setText((int) (howMuchProgress * 100) + "%");
        } else {
            percentageLabel.setText("100%");
        }
    }

    public void reset() {
        refresh = true;
        howMuchProgress = 0;
        txtLabel.setText("");
        mobileNumber.setText("");
        percentageLabel.setText("");
        mobileNumber.requestFocus();
        studentProgress.setProgress(0);
        showPromotedOrNotLabel.setText("");
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        studentProgress.setStyle("-fx-accent:  #CD853F;");
    }
}