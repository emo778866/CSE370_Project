package sample;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import javax.xml.soap.Text;
import java.io.IOException;
import java.sql.*;

public class updateComp {
    @FXML Button update;
    @FXML
    TextField cou1,cou2,cou3,cou4,cou5;
    @FXML
    void initialize(){
        update.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                String c1= cou1.getText(); //new value
                String c2= cou2.getText();
                String c3= cou3.getText();
                String c4= cou4.getText();
                String c5= cou5.getText();


                try {
                    Class.forName("com.mysql.jdbc.Driver");
                    Connection con= DriverManager.getConnection(
                            "jdbc:mysql://127.0.0.1/martial","root","");
                    Statement stmt=con.createStatement();

                    String query = "update competition set name='"+c2+"', sponsor='"+c3+"',start_date='"+c4+"', end_date='"+c5+"' where ID='"+c1+"';";
                    System.out.println(query);
                    stmt.executeUpdate(query);
                } catch (ClassNotFoundException | SQLException e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
