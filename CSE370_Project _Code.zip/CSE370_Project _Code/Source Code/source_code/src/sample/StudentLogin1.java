package sample;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.util.Callback;

import javax.xml.soap.Text;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class StudentLogin1 {
    @FXML
    GridPane gPan;
    @FXML
    TextField tEmail;

    @FXML
    PasswordField tPassword;

    @FXML
    Button tLogin;
    @FXML
    void initialize(){
        tLogin.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                String email = tEmail.getText();
                String pass = tPassword.getText();
                try{
                    Class.forName("com.mysql.jdbc.Driver");
                    Connection con= DriverManager.getConnection(
                            "jdbc:mysql://127.0.0.1/martial","root","");
                    Statement stmt=con.createStatement();
                    ResultSet rs=stmt.executeQuery("select * from students where email = '"+email+"' AND contact = '"+pass+"'");
                    int size = 0;
                    while(rs.next())
                        size++;
                    if(size==1){
                        Stage ps = (Stage) tEmail.getScene().getWindow();
                        Parent nextPage = null;

                        try {
                            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("StudentHome.fxml"));
                            fxmlLoader.setControllerFactory(new Callback<Class<?>, Object>() {
                                @Override
                                public Object call(Class<?> controllerClass) {
                                    if (controllerClass == StudentHome.class) {
                                        StudentHome controller = new StudentHome();
                                        controller.setContact(pass);
                                        return controller ;
                                    } else {
                                        try {
                                            return controllerClass.newInstance();
                                        } catch (Exception exc) {
                                            throw new RuntimeException(exc); // just bail
                                        }
                                    }
                                }
                            });
                            nextPage = fxmlLoader.load();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        ps.getScene().setRoot(nextPage);
                    }else{
                        Alert alert = new Alert(Alert.AlertType.ERROR,"Incorrect email or password");
                        alert.showAndWait();
                    }
                }catch(Exception e){
                    System.out.println(e);
                }
            }
        });
    }


}