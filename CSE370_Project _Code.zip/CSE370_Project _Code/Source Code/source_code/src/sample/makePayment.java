package sample;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import javax.xml.soap.Text;
import java.io.IOException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.util.Date;
import java.sql.*;

public class makePayment {
    @FXML
    Button create;
    @FXML
    TextField com1, com2, com3, com4;

    @FXML
    void initialize() {

        LocalDate currentDate = LocalDate.now();
        DayOfWeek dow = currentDate.getDayOfWeek();
        int dom = currentDate.getDayOfMonth();
        int doy = currentDate.getDayOfYear();
        Month m = currentDate.getMonth();
        int y = currentDate.getYear();
        String month = m.name();
        String  year = String.valueOf(y);
        System.out.println(month);
        System.out.println(year);


        create.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {

                String c1 = com1.getText();
                String c2 = com2.getText();
                String c3 = com3.getText();

                String c4 = com4.getText();

                int b=Integer.parseInt(c1);
                String q1="select balance from students where contact='"+b+"';";
                ResultSet v= rsq(q1);




                
                try {
                    v.next();
                    int current=v.getInt(1);
                    int a=Integer.parseInt(c3);
                    current = current-a;
                    String x="update students set balance= "+current+" where contact='"+b+"';";
                    System.out.println(x);
                    rsUp(x);


                    String p=String.format("select balance from account where month = '%s' AND year = '%s'", month, year);

                    ResultSet v1= rsq(p);

                    v1.next();
                    int current1=v1.getInt(1);
                    int c=Integer.parseInt(c3);
                    current1=c+current1;
                    String y = String.format("update account set balance = %d where month = '%s' AND year = '%s'",
                            current1, month, year);
                    System.out.println(y);
                    rsUp(y);




                    Class.forName("com.mysql.jdbc.Driver");
                    Connection con = DriverManager.getConnection(
                            "jdbc:mysql://127.0.0.1/martial", "root", "");
                    Statement stmt = con.createStatement();

                    String query = "insert into pays (student_contact,T_email, amount, due_date, payment_date) values ('" + c1 + "','" + c2 + "','" + c3 + "','2021-05-31','" + c4 + "')";


                    System.out.println(query);
                    stmt.executeUpdate(query);
                    System.out.println("SUCCESSFUL");
                }
                catch (ClassNotFoundException | SQLException e) {
                    e.printStackTrace();
                }
            }
        });

    }

    ResultSet rsq(String q) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://127.0.0.1/martial", "root", "");
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(q);
            return rs;

        } catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }
    void rsUp(String qu){
        try {

            Class.forName("com.mysql.jdbc.Driver");
            Connection con= DriverManager.getConnection(
                    "jdbc:mysql://127.0.0.1/martial","root","");
            Statement stmt=con.createStatement();
            stmt.executeUpdate(qu);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

}