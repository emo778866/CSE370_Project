package sample;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class TrainerHomeF {

    @FXML
    Button cr,pr,nr;
    @FXML
    void initialize(){
        cr.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Stage ps = (Stage) cr.getScene().getWindow();
                Parent nextPage = null;
                ps.setTitle("Create Competition");
                try {
                    nextPage = FXMLLoader.load(getClass().getResource("createComp.fxml"));
                } catch (IOException e) {
                    e.printStackTrace();
                }
                ps.getScene().setRoot(nextPage);
            }
        });
        pr.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Stage pt = (Stage) pr.getScene().getWindow();
                Parent nextPages = null;
                pt.setTitle("Update Competition");
                try {
                    nextPages = FXMLLoader.load(getClass().getResource("updateComp.fxml"));
                } catch (IOException e) {
                    e.printStackTrace();

                }

                pt.getScene().setRoot(nextPages);
            }
        });

        nr.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Stage pt = (Stage) nr.getScene().getWindow();
                Parent nextPages = null;
                pt.setTitle("Update Competition");
                try {
                    nextPages = FXMLLoader.load(getClass().getResource("showComp.fxml"));
                } catch (IOException e) {
                    e.printStackTrace();

                }

                pt.getScene().setRoot(nextPages);
            }
        });
    }
}
