package sample;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import javax.xml.soap.Text;
import java.io.IOException;
import java.sql.*;

public class createComp {
    @FXML Button create;
    @FXML TextField com1,com2,com3,com4,com5;
    @FXML void initialize(){
    create.setOnAction(new EventHandler<ActionEvent>() {
        @Override
        public void handle(ActionEvent event) {
            String c1= com1.getText();
            String c2= com2.getText();
            String c3= com3.getText();
            String c4= com4.getText();
            String c5= com5.getText();


            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection con= DriverManager.getConnection(
                        "jdbc:mysql://127.0.0.1/martial","root","");
                Statement stmt=con.createStatement();

                String query = "insert into competition values('"+c1+"','"+c2+"','"+c3+"','"+c4+"','"+c5+"');";
                System.out.println(query);
                stmt.executeUpdate(query);
            } catch (ClassNotFoundException | SQLException e) {
                e.printStackTrace();
            }
        }
    });
}
}
