package sample;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;

import javafx.*;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.util.Callback;

import java.io.IOException;
import java.sql.*;

public class StudentLogin {
    @FXML
    Button login;
    @FXML
    TextField cont;
    @FXML
    void initialize(){
        login.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                String s = cont.getText();
                ;
                String qu = String.format("select contact from students where contact = '%s'", s);
                ResultSet rs = rsq(qu);
                try{
                    int siz = 0;
                    while(rs.next()){
                        System.out.println(rs.getString(1));
                        siz++;
                    }
                    if(siz == 1){
                        Stage ps = (Stage) login.getScene().getWindow();
                        Parent nextPage = null;
                        ps.setTitle(s);
                        try {
                            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("StudentNotifications.fxml"));
                            fxmlLoader.setControllerFactory(new Callback<Class<?>, Object>() {
                                @Override
                                public Object call(Class<?> controllerClass) {
                                    if (controllerClass == StudentNotfications.class) {
                                        StudentNotfications controller = new StudentNotfications();
                                        controller.setSt_con(s);
                                        return controller ;
                                    } else {
                                        try {
                                            return controllerClass.newInstance();
                                        } catch (Exception exc) {
                                            throw new RuntimeException(exc); // just bail
                                        }
                                    }
                                }
                            });
                            nextPage = fxmlLoader.load();
                        } catch (IOException e) {
                            e.printStackTrace();
                            System.out.println(e.toString());
                        }
                        ps.getScene().setRoot(nextPage);
                    }
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                    System.out.println(throwables.toString());
                }
            }
        });

    }
    ResultSet rsq(String query){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con= DriverManager.getConnection(
                    "jdbc:mysql://127.0.0.1/martial","root","");
            Statement stmt=con.createStatement();
            ResultSet rs=stmt.executeQuery(query);
            return rs;

        }catch(Exception e){
            System.out.println(e);
        }
        return  null;
    }
}
