package sample;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class SangTongWelcome {
    @FXML
    Button stdNot, tHome, manageComp, paym, bTest;
    @FXML
    void initialize(){
        stdNot.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Stage ps = (Stage) stdNot.getScene().getWindow();
                Parent nextPage = null;
                try {
                    nextPage = FXMLLoader.load(getClass().getResource("StudentLogin.fxml"));
                } catch (IOException e) {
                    e.printStackTrace();
                }
                ps.getScene().setRoot(nextPage);
            }
        });

        tHome.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Stage ps = (Stage) tHome.getScene().getWindow();
                Parent nextPage = null;
                try {
                    nextPage = FXMLLoader.load(getClass().getResource("TrainerLogin.fxml"));
                } catch (IOException e) {
                    e.printStackTrace();
                }
                ps.getScene().setRoot(nextPage);
            }
        });

        manageComp.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Stage ps = (Stage) tHome.getScene().getWindow();
                Parent nextPage = null;
                try {
                    nextPage = FXMLLoader.load(getClass().getResource("TrainerLoginF.fxml"));
                } catch (IOException e) {
                    e.printStackTrace();
                }
                ps.getScene().setRoot(nextPage);
            }
        });

        paym.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Stage ps = (Stage) tHome.getScene().getWindow();
                Parent nextPage = null;
                try {
                    nextPage = FXMLLoader.load(getClass().getResource("StudentLogin1.fxml"));
                } catch (IOException e) {
                    e.printStackTrace();
                }
                ps.getScene().setRoot(nextPage);
            }
        });

        bTest.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Stage ps = (Stage) tHome.getScene().getWindow();
                Parent nextPage = null;
                try {
                    nextPage = FXMLLoader.load(getClass().getResource("Welcome.fxml"));
                } catch (IOException e) {
                    e.printStackTrace();
                }
                ps.getScene().setRoot(nextPage);
            }
        });
    }
}
