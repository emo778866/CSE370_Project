//package sample;
//import javafx.event.ActionEvent;
//import javafx.event.EventHandler;
//import javafx.fxml.FXML;
//import javafx.fxml.FXMLLoader;
//import javafx.scene.Parent;
//import javafx.scene.control.*;
//import javafx.scene.layout.GridPane;
//import javafx.stage.Stage;
//
//import javax.xml.soap.Text;
//import java.io.IOException;
//import java.sql.*;
//public class showPayment {
//
//    @FXML Label got;
//    @FXML void initialize(){
//        try {
//            Class.forName("com.mysql.jdbc.Driver");
//            Connection con= DriverManager.getConnection(
//                    "jdbc:mysql://127.0.0.1/martial","root","");
//            Statement stmt=con.createStatement();
//
//            String query = "select contact, balance from pays";
//            ResultSet rs=rsq(query);
////            if (due_date)
//            while(rs.next())
//                got.setText(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"  "+rs.getString(4));
//            stmt.execute(query);
//        } catch (ClassNotFoundException | SQLException e) {
//            e.printStackTrace();
//        }
//    }
//
//
//    ResultSet rsq(String query){
//        try{
//            Class.forName("com.mysql.jdbc.Driver");
//            Connection con= DriverManager.getConnection(
//                    "jdbc:mysql://127.0.0.1/martial","root","");
//            Statement stmt=con.createStatement();
//            ResultSet rs=stmt.executeQuery(query);
//            return rs;
//
//        }catch(Exception e){
//            System.out.println(e);
//        }
//        return  null;
//    }
//}
package sample;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.util.Callback;

import javax.xml.soap.Text;
import java.io.IOException;
import java.sql.*;
public class showPayment {
    String std_contact;
    @FXML Button bt;
    @FXML Label got;


    @FXML void initialize(){
        bt.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Stage ps = (Stage) bt.getScene().getWindow();
                Parent nextPage = null;

                try {
                    FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("StudentHome.fxml"));
                    fxmlLoader.setControllerFactory(new Callback<Class<?>, Object>() {
                        @Override
                        public Object call(Class<?> controllerClass) {
                            if (controllerClass == StudentHome.class) {
                                StudentHome controller = new StudentHome();
                                controller.setContact(std_contact);
                                return controller ;
                            } else {
                                try {
                                    return controllerClass.newInstance();
                                } catch (Exception exc) {
                                    throw new RuntimeException(exc); // just bail
                                }
                            }
                        }
                    });
                    nextPage = fxmlLoader.load();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                ps.getScene().setRoot(nextPage);
            }
        });
        System.out.println(std_contact);
        try {

            String query = String.format("select * from pays where student_contact = '%s'", std_contact);
            ResultSet rs=rsq(query);
            int size = 0;
            while(rs.next()) {
                size++;
            }
            if(size == 1){
                got.setText("yayyy! Payment complete :)");
            }else{
                got.setText("ooops! Payment incomplete :(");
            }
        } catch ( SQLException e) {
            e.printStackTrace();
        }
    }

    void setContact(String a){
        this.std_contact = a;
    }


    ResultSet rsq(String query){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con= DriverManager.getConnection(
                    "jdbc:mysql://127.0.0.1/martial","root","");
            Statement stmt=con.createStatement();
            ResultSet rs=stmt.executeQuery(query);
            return rs;

        }catch(Exception e){
            System.out.println(e);
        }
        return  null;
    }
}