package sample;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.util.Callback;

import java.io.IOException;

public class StudentHome {
    String stdContact=null;

    @FXML
    Button nr,cr;

    @FXML
    void initialize(){


       nr.setOnAction(new EventHandler<ActionEvent>() {
           @Override
           public void handle(ActionEvent event) {
                Stage ps = (Stage) nr.getScene().getWindow();
               Parent nextPage = null;
               try {
                   FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("showPayment.fxml"));

                   fxmlLoader.setControllerFactory(new Callback<Class<?>, Object>() {
                       @Override
                       public Object call(Class<?> controllerClass) {
                           if (controllerClass == showPayment.class) {
                               showPayment controller = new showPayment();
                               controller.setContact(stdContact);
                               return controller ;
                           } else {
                               try {
                                   return controllerClass.newInstance();
                               } catch (Exception exc) {
                                   throw new RuntimeException(exc); // just bail
                               }
                           }
                       }
                   });
                   nextPage = fxmlLoader.load();
               }
               catch (IOException e) {
                   e.printStackTrace();
               }
               ps.getScene().setRoot(nextPage);
          }
        });
        cr.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Stage ps = (Stage) cr.getScene().getWindow();
                Parent nextPage = null;
                ps.setTitle("Make Payment");
                try {
                    nextPage = FXMLLoader.load(getClass().getResource("makePayment.fxml"));
                } catch (IOException e) {
                    e.printStackTrace();
                }
                ps.getScene().setRoot(nextPage);
            }
        });
   }
   public void setContact(String a){
        stdContact=a;


   }
}