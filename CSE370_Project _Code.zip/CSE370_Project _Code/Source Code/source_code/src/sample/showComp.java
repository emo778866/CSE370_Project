package sample;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import javax.xml.soap.Text;
import java.io.IOException;
import java.sql.*;
public class showComp {

@FXML Label got;
    @FXML void initialize(){
        try {
            String jol= "";
            Class.forName("com.mysql.jdbc.Driver");
            Connection con= DriverManager.getConnection(
                    "jdbc:mysql://127.0.0.1/martial","root","");
            Statement stmt=con.createStatement();

            String query = "select * from competition;";
            ResultSet rs=rsq(query);
            while(rs.next())
                jol+=rs.getString(5)+"  "+rs.getString(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"  "+rs.getString(4) +"\n";

            System.out.println(jol);
            System.out.println(query);
            got.setText(jol);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }

    }


    ResultSet rsq(String query){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con= DriverManager.getConnection(
                    "jdbc:mysql://127.0.0.1/martial","root","");
            Statement stmt=con.createStatement();
            ResultSet rs=stmt.executeQuery(query);
            return rs;

        }catch(Exception e){
            System.out.println(e);
        }
        return  null;
    }
}
