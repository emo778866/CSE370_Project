package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;
import java.util.Objects;

public class Participation_Done {
    boolean done = false;
    private String pno, compName, compId;
    private Date date;
    private final int pointsEarned = (int) (Math.random() * (50 - 1 + 1) + 1);

    @FXML
    private javafx.scene.control.Label compNameLabel, compReportLabel, pointsLabel;
    Connection con;
    PreparedStatement st;

    {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://127.0.0.1/martial", "root", "");
        } catch (Exception e) {
            System.out.println();
        }
    }

    public void phoneNo(String _pno) {
        pno = _pno;
    }

    public void dateOfComp(Date _date) {
        date = _date;
    }

    public void nameOfComp(String _compName) {
        compName = _compName;
    }

    public void idOfComp(String _compID) {
        compId = _compID;
    }

    public void add() {
        try {
            if (!done) {
                compNameLabel.setText("Welcome to " + compName);
                compReportLabel.setText("You have successfully participated in the competition \n                   " +
                        "         and scored points");
                pointsLabel.setText("" + pointsEarned + "!");
                st = con.prepareStatement("insert into participates values (?,?,?,?)");
                st.setString(1, pno);
                st.setDate(2, date);
                st.setInt(3, pointsEarned);
                st.setString(4, compId);
                st.executeUpdate();
                done = true;
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public void welcome(ActionEvent event) throws IOException {
        set("Welcome.fxml", event);
    }


    public void set(String sendTo, ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource(sendTo)));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}