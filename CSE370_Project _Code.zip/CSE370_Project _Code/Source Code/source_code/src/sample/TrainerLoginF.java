package sample;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import javax.xml.soap.Text;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class TrainerLoginF {
    @FXML
    GridPane gPan;
    @FXML
    TextField tEmail;

    @FXML
    PasswordField tPassword;

    @FXML
    Button tLogin;
    @FXML
    void initialize(){
        tLogin.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                String email = tEmail.getText();
                String pass = tPassword.getText();
                try{
                    Class.forName("com.mysql.jdbc.Driver");
                    Connection con= DriverManager.getConnection(
                            "jdbc:mysql://127.0.0.1/martial","root","");
                    Statement stmt=con.createStatement();
                    ResultSet rs=stmt.executeQuery("select * from trainer where email = '"+email+"' AND password = '"+pass+"';");
                    int size = 0;
                    while(rs.next())
                        size++;
                    if(size == 1){
                        Stage ps = (Stage) tEmail.getScene().getWindow();
                        Parent nextPage = null;
                        ps.setTitle("Home");
                        try {
                            nextPage = FXMLLoader.load(getClass().getResource("TrainerHomeF.fxml"));
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        ps.getScene().setRoot(nextPage);
                    }else{
                        Alert alert = new Alert(Alert.AlertType.ERROR,"Incorrect email or password");
                        alert.showAndWait();
                    }
                }catch(Exception e){
                    System.out.println(e);
                }
            }
        });
    }


}