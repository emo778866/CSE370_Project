package sample;

import com.sun.org.apache.bcel.internal.generic.ARETURN;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.text.*;
import javafx.stage.Stage;
import javafx.util.Callback;


import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class TrainerHome {
    @FXML
    ListView std_list;
    @FXML Button sendNot;
    @FXML
    TextField notifText, searchStudent;
    @FXML
    TextFlow schedule;

    @FXML
    Text tt, stEn;
    private String tmail;
    private         List<String>        stringList     = new ArrayList<>(5);
    private ObservableList observableList = FXCollections.observableArrayList();
    @FXML
    void initialize(){
        tt.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
        stEn.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));


        String qu = String.format("select day, GROUP_CONCAT(DISTINCT(time)) FROM trains where T_email = '%s' GROUP BY day;", tmail);
        ResultSet rsc = rsq(qu);


        updateStdList("");

        Text op = new Text("Day                                    Time\n" +
                           "-------------------------------------------\n");
        schedule.getChildren().add(op);

        try{
            while(rsc.next()){
                Text t = new Text(rsc.getString(1) + "         " + rsc.getString(2)+"\n");
                t.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 15));
                t.setFill(Color.GREEN);
                schedule.getChildren().add(t);
              //  cur += rsc.getString(1)+" "+rsc.getString(2)+"\n";
            }


            std_list.setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent event) {
                    Dialog<String> dl = new Dialog<>();
                    ButtonType type = new ButtonType("Ok", ButtonBar.ButtonData.OK_DONE);
                    dl.getDialogPane().getButtonTypes().add(type);
                    String sli = (String) std_list.getSelectionModel().getSelectedItem();
                    dl.setTitle("Student information: " + sli);
                    ResultSet rs = rsq(String.format("select * from students where name  = '%s'", sli));
                    try {
                        rs.next();
                        dl.setContentText("Contact: "+rs.getString(5)+"\n"
                                         +"Name: "+rs.getString(4) + "\n"
                                         +"Belt: "+rs.getString(6) + "\n"
                                          +"Address: "+rs.getString(2));
                    } catch (SQLException throwables) {
                        throwables.printStackTrace();
                    }
                    dl.showAndWait();

                }
            });


/*            String query = String.format("select * from trains where T_email = '%s';", tmail);
            ResultSet rs=rsq(query);
            System.out.println(query);
            while(rs.next()) {
                String name= rs.getString(5);
                String qu = String.format("select * from students where contact = '%s';", name );
                ResultSet r = rsq(qu);
                r.next();

                stringList.add(r.getString(4));

            }*/
        }catch(Exception e){
            System.out.println(e);
        }
        /*observableList.setAll(stringList);

        std_list.setItems(observableList);*/

        sendNot.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                String query = String.format("insert into notifications values('%s', '%s\n    %s')", tmail, getCurrentDateTime(), notifText.getText());
                rsUp(query);
                notifText.setText("");
            }
        });

        searchStudent.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                updateStdList(newValue);
            }
        });

    }

    void updateStdList(String key){
        std_list.getItems().clear();
        stringList.clear();
        try {
            String query = "select student_name, student_contact from trains where T_email = '" + tmail + "' " +
                    "AND (student_contact LIKE  '%"+key+"%' OR student_name LIKE '%"+key+"%');";
            ResultSet rs = rsq(query);
            System.out.println(query);
            while (rs.next()) {
                stringList.add(rs.getString(1));

            }
            observableList.setAll(stringList);

            std_list.setItems(observableList);
        }catch (Exception e){

        }
    }

    String getCurrentDateTime(){
        LocalDateTime myDateObj = LocalDateTime.now();
        //System.out.println("Before formatting: " + myDateObj);
        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");

        String formattedDate = myDateObj.format(myFormatObj);
        return formattedDate;
    }

    void setMail(String mail){
        this.tmail = mail;
    }

    ResultSet rsq(String query){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con= DriverManager.getConnection(
                    "jdbc:mysql://127.0.0.1/martial","root","");
            Statement stmt=con.createStatement();
            ResultSet rs=stmt.executeQuery(query);
            return rs;

        }catch(Exception e){
            System.out.println(e);
        }
        return  null;
    }

    void rsUp(String qu){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con= DriverManager.getConnection(
                    "jdbc:mysql://127.0.0.1/martial","root","");
            Statement stmt=con.createStatement();
            stmt.executeUpdate(qu);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

}
