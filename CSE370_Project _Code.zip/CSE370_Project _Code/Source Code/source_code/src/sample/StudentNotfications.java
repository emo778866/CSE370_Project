package sample;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import javafx.scene.control.ListView;
import javafx.scene.paint.Color;
import javafx.scene.text.*;
import javafx.util.Duration;

public class StudentNotfications {
    String  st_con;
    @FXML
    TextFlow st_notview;

    @FXML Text nsy;
    @FXML
    void initialize(){

        nsy.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));

        Timeline timer = new Timeline(
                new KeyFrame(Duration.seconds(2),
                        new EventHandler<ActionEvent>() {

                            @Override
                            public void handle(ActionEvent event) {
                                st_notview.getChildren().clear();
                                populateNotifications();
                            }
                        }));
        timer.setCycleCount(Timeline.INDEFINITE);
        timer.play();


    }

    void populateNotifications(){
        try{
            String qu = String.format("select * from notifications where T_mail IN(select T_email from trains  where  student_contact = '%s');", st_con);
            ResultSet rs = rsq(qu);
            while(rs.next()) {

                String query = String.format("select name from trainer where email = '%s'", rs.getString(1));

                ResultSet rsh = rsq(query);
                rsh.next();
                Text fn = new Text("    "+rsh.getString(1)+"   ");
                fn.setFill(Color.CHOCOLATE);
                fn.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
                Text nte = new Text(rs.getString(2) + "\n" +
                        "--------------------------------------------------------------------\n");
                nte.setFont(Font.font("verdana", FontWeight.NORMAL, FontPosture.REGULAR, 15));
                st_notview.getChildren().add(fn);
                st_notview.getChildren().add(nte);

                //System.out.println(rs.getString(1));
            }
        }catch(Exception e){
            System.out.println(e);
        }
    }

    void setSt_con(String s){
        this.st_con = s;
    }

    ResultSet rsq(String query){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con= DriverManager.getConnection(
                    "jdbc:mysql://127.0.0.1/martial","root","");
            Statement stmt=con.createStatement();
            ResultSet rs=stmt.executeQuery(query);
            return rs;

        }catch(Exception e){
            System.out.println(e);
        }
        return  null;
    }
}
