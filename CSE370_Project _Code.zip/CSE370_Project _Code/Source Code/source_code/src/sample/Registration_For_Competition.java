package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

public class Registration_For_Competition {
    Connection con;
    private Date startDate, endDate;
    private boolean foundInDB = false;
    private String phoneNumber = "", userName = "", competitionName = "", compID = "";
    private final Set<String> set = new HashSet<>();
    @FXML
    private Label regDoneMessageLabel;
    @FXML
    private javafx.scene.control.Button button;
    @FXML
    private javafx.scene.control.TextField mobileNumber, mobileNumber2;


    {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://127.0.0.1/martial", "root", "");
        } catch (Exception ignored) {

        }
    }

    public void submit() throws SQLException {
        phoneNumber = mobileNumber.getText();
        Statement ST = con.createStatement();
        Statement FS = con.createStatement();
        Statement FP = con.createStatement();
        ResultSet fc = ST.executeQuery("select * from competition order by start_date desc " +
                "limit 1");
        ResultSet fs = FS.executeQuery("select name, contact from students");
        ResultSet fp = FP.executeQuery(String.format("select start_date from participates where student_contact = " +
                "'%s';", phoneNumber));
        try {
            if (phoneNumber.length() != 11 || notNumber(mobileNumber)) {
                showErrorMessage();
                setFocus();
            } else {
                getUName(fs);
                getCNameDate(fc);
                if (foundInDB) {
                    if (alreadyParticipated(fp)) {
                        regDoneMessageLabel.setText("You have already participated in the competition!");
                        setFocus();
                    } else if (competitionEnded()) {
                        regDoneMessageLabel.setText("Sorry, latest competition has ended!");
                        setFocus();
                    } else {
                        if (inTheRegList(phoneNumber)) {
                            regDoneMessageLabel.setText("Hey, " + userName + " reg done :)");
                        } else {
                            regDoneMessageLabel.setText("You have already registered, go and participate " +
                                    "now!");
                        }
                        set.add(phoneNumber);
                        mobileNumber.setText("");
                        button.requestFocus();
                    }
                } else {
                    regDoneMessageLabel.setText("Sorry you are not a valid student!");
                    setFocus();
                }

            }
        } catch (Exception e) {
            showErrorMessage();
            setFocus();
        }
    }

    private boolean inTheRegList(String _phoneNumber) {
        for (String pn : set) {
            if (pn.equals(_phoneNumber)) {
                return false;
            }
        }
        return true;
    }

    //****************************************************//
    private void getUName(ResultSet rs) throws SQLException {
        while (rs.next()) {
            if (rs.getString(2).equals(phoneNumber)) {
                foundInDB = true;
                userName = rs.getString(1);
            }
        }
    }

    //*********************************************************//
    private void getCNameDate(ResultSet rs) throws SQLException {
        while (rs.next()) {
            competitionName = rs.getString(1);
            startDate = rs.getDate(3);
            endDate = rs.getDate(4);
            compID = rs.getString(5);
        }
    }

    //************************************//
    private boolean notNumber(TextField s) {
        String str = String.valueOf(s);
        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);
            if (c < '0' || c > '9') {
                return false;
            }
        }
        return true;
    }

    //*******************************************************************//
    private boolean alreadyParticipated(ResultSet rs) throws SQLException {
        while (rs.next()) {
            if (rs.getString(1).equals(String.valueOf(startDate))) {
                return true;
            }
        }
        return false;
    }

    //********************************//
    private boolean competitionEnded() {
        Date today = Date.valueOf(java.time.LocalDate.now());
        return today.compareTo(endDate) > 0;
    }

    //*****************************//
    private void showErrorMessage() {
        regDoneMessageLabel.setText("Sorry you did not enter a mobile number!");
    }

    //*********************//
    private void setFocus() {
        mobileNumber.setText("");
        mobileNumber.requestFocus();
    }

    //************************************************************************//
    public void toCompetitionResultCheck(ActionEvent event) throws IOException {
        String phoneNumber2;
        phoneNumber2 = mobileNumber2.getText();
        if (phoneNumber2.equals("")) {
            regDoneMessageLabel.setText("Mobile number can't be empty!");
            mobileNumber2.setText("");
            mobileNumber2.requestFocus();
        } else if (inTheRegList(phoneNumber2)) {
            regDoneMessageLabel.setText("Please register first!");
            mobileNumber.requestFocus();
            mobileNumber2.setText("");
        } else if (!inTheRegList(phoneNumber2)) {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Participation_Done.fxml"));
            Parent root = loader.load();
            Participation_Done obj = loader.getController();
            obj.phoneNo(phoneNumber);
            obj.dateOfComp(startDate);
            obj.nameOfComp(competitionName);
            obj.idOfComp(compID);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } else {
            regDoneMessageLabel.setText("Wrong number or not a mobile number!");
            mobileNumber2.setText("");
            mobileNumber2.requestFocus();
        }
    }

    public void welcome(ActionEvent event) throws IOException {
        set("Welcome.fxml", event);
    }


    public void set(String sendTo, ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource(sendTo)));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}